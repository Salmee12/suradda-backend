import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.models.room import Room, RoomParticipant, generate_room_code
from app.models.user import User
from app.schemas.room import RoomJoin, RoomState
from app.core.dependencies import get_current_user, get_subscribed_user
from app.services.websocket_manager import manager
from app.services.room_cleanup import leave_room_cleanup, touch_room_activity

router = APIRouter()


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


async def _room_state(db: AsyncSession, room: Room) -> RoomState:
    return RoomState(
        id=room.id,
        code=room.code,
        host_id=room.host_id,
        current_song_id=room.current_song_id,
        current_position_ms=room.current_position_ms,
        is_playing=room.is_playing,
        is_active=room.is_active,
        participant_count=manager.participant_count(room.id),
    )


@router.post("/create", response_model=RoomState, status_code=201)
async def create_room(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_subscribed_user),
):
    code = generate_room_code()
    while (await db.execute(select(Room).where(Room.code == code))).scalar_one_or_none():
        code = generate_room_code()

    now = _utcnow()
    room = Room(
        code=code,
        host_id=current_user.id,
        last_activity_at=now,
    )
    db.add(room)
    await db.flush()

    participant = RoomParticipant(room_id=room.id, user_id=current_user.id)
    db.add(participant)
    await db.commit()
    await db.refresh(room)

    return await _room_state(db, room)


@router.post("/join", response_model=RoomState)
async def join_room(
    payload: RoomJoin,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_subscribed_user),
):
    result = await db.execute(
        select(Room).where(Room.code == payload.code.upper(), Room.is_active == True)
    )
    room = result.scalar_one_or_none()
    if not room:
        raise HTTPException(status_code=404, detail="Party not found or has ended")

    existing = await db.execute(
        select(RoomParticipant).where(
            RoomParticipant.room_id == room.id, RoomParticipant.user_id == current_user.id
        )
    )
    if not existing.scalar_one_or_none():
        db.add(RoomParticipant(room_id=room.id, user_id=current_user.id))
        await db.commit()

    await touch_room_activity(db, room.id)
    await db.refresh(room)
    return await _room_state(db, room)


@router.get("/{room_id}", response_model=RoomState)
async def get_room(
    room_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Room).where(Room.id == room_id))
    room = result.scalar_one_or_none()
    if not room:
        raise HTTPException(status_code=404, detail="Party not found")
    return await _room_state(db, room)


@router.post("/{room_id}/leave", status_code=204)
async def leave_room(
    room_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    # Never gated. Blocking a lapsed subscriber from leaving would strand their
    # room open with them listed as host.
    current_user: User = Depends(get_current_user),
):
    """
    Leave the party. Host leave closes the room for everyone.
    Non-host leave removes only that user; an empty room is closed.
    """
    await leave_room_cleanup(db, room_id, current_user.id)
    return None